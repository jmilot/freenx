#ifdef NXAGENT_UPGRADE

#include "X/NXdamage.c"

#endif
