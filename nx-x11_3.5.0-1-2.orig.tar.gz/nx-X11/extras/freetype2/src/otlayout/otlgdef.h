#ifndef __OTL_GDEF_H__
#define __OTL_GDEF_H__

#include "otltable.h"

OTL_BEGIN_HEADER

  OTL_API( void )
  otl_gdef_validate( OTL_Bytes  table,
                     OTL_Valid  valid );

OTL_END_HEADER

#endif /* __OTL_GDEF_H__ */
